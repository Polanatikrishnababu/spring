package com.cg;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {
	public static void main(String[] args) {
		Resource resource =new ClassPathResource("currencyConverter.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		CurrencyConverter curency=(CurrencyConverter) factory.getBean("CurrencyConverter");
		double result=curency.dollarToRupees(50.0);
		System.out.println("50 dollars is  "+result);
	}

}


