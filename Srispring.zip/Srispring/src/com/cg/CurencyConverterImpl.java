package com.cg;
public class CurencyConverterImpl implements CurrencyConverter{

 
/*
    public CurencyConverterImpl() {
		super();
		// TODO Auto-generated constructor stub
	}*/
	private ExchangeService exchangeService;
	public CurencyConverterImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

    public ExchangeService getExchangeService() {
		return exchangeService;
	}

	public void setExchangeService(ExchangeService exchangeService) {
		this.exchangeService = exchangeService;
	}

	
	@Override
    public double dollarToRupees(double dollars) {
        System.out.println("dollarToRupees() Invoked");
        return dollars*exchangeService.getExchangeRate();
    }
	/*public double getExchangeRate() {
		return exchangeRate;
	}
	public void setExchangeRate(double exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
*/
 

}
 

