package com.cg;

public class ExchangeServiceImpl implements ExchangeService {
private double exchangeRate;


public ExchangeServiceImpl(double exchangeRate) {
	super();
	this.exchangeRate = exchangeRate;
}


@Override
public double getExchangeRate() {
	// TODO Auto-generated method stub
	
	return exchangeRate;
}



	
}
